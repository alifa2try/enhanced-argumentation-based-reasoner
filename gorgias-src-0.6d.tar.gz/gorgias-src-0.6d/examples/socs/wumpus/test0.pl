%%% No behaviour yet. Just proceed until Timepoint 5 and note that the agent
%%% realizes of the failed action. Note that the world is not fully accessible
%%% to the agent. S/he does not even know that we are playing on a 4x4 board.

:- compile('wumpus').
:- start.

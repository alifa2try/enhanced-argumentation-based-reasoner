:- compile('wumpus').


self(profile,impatient).

:- start.

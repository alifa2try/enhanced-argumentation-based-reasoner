
:- compile(ct).
rule(self1, self(behavior,punctual), []).



rule(f(1),at(nothing_urgent,1),[]).
